#include <stdio.h>
int main()
{
    double M[12][12], soma = 0, media = 0;
    int i, j, x = 1, y = 11;
    char O;
    scanf("%s/n" , &O);

    for(i = 0; i < 12; i++){
        for(j = 0; j < 12; j++){
            scanf("%lf" , &M[i][j] );
        }
	}

    /*for(i=0; i < 12; i++){

        for(int j=0; j < 12; j++){
            printf("%.0lf ", M[i][j]);
        }
        
        printf("\n");

	}*/
    for(i = 0; i < 5; i++){
         for(j = x; j < y; j++){
            soma += M[i][j];
            
        }
        x++;
        y--;
    }

    if(O == 'S'){
        printf("%.1lf", soma);
    }
    else if(O == 'M'){
        media = soma / 30;
        printf("%.1lf", media);
    }


    /*
    Preencha a sua implementacao aqui
    - declare suas variáveis
    - faca a leitura e some os valores
    - se necessario, calcule a media
    - imprima o resultado no formato correto
    */

    return 0;
}
